# Python package for Entropy-Based Distance Metric 

To run the documentation website, open <code>docs/_build/html/index.html</code>

*If you're making changes to the source code, make sure that you compile a clean build in the shell using*
<code>make clean; make html</code>
